﻿using System.Collections.Generic;

namespace MediaInteractiveaAPI.Services.ViewModels
{
    public class EmployeeData
    {
        public string Name { get; set; }
        public string Lastname { get; set; }
        public string IsMediaInteractivaEmp { get; set; }
        public List<Animal> Animals { get; set; }
      

    }

    public class Animal
    {
        public string TypeOfAnimal { get; set; }
        public string PetName { get; set; }
        public string Ownername { get; set; }
    }
    
}
