﻿namespace MediaInteractiveaAPI.Services.Common
{
    public class Constants
    {
        public const string databaseName = "MediaInteractivea";
        public const string controllerIn = "ControllerIn";
        public const string controllerOut = "ControllerOut";
        public const string serviceIn = "ServiceIn";
        public const string serviceOut = "ServiceOut";
        public const string exceptionThrown = "Exception Thrown";

        public const string mistatusDbParam = "@miStatus";
        public const string mistatus = "miStatus";
    }
}
