﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using MediaInteractiveaAPI.Services.Services;
using MediaInteractiveaAPI.Services.ViewModels;
using MediaInteractiveaAPI.Services.DataModels;
using MediaInteractiveaAPI.Services.Common;
using System.Linq;
namespace MediaInteractiveaAPI.Services.Controllers
{
    [Route("api/employee")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployeeServices _employeeServices;
        

        private int _status;

        public EmployeeController(IEmployeeServices employeeServices)
        {
            _employeeServices = employeeServices;
            
        }

        //GET api/employee
        /// <summary>Returns all employee details</summary>
        /// <returns>All Employee Details</returns>
        [Route("")]
        [HttpGet]
        public ActionResult<List<EmployeeData>> GetEmployees()
        {
            TraceLog.LogActivity(Constants.controllerIn, RouteData, "");
            var employeeDataDMs = new List<EmployeeDataDM>();
            employeeDataDMs = _employeeServices.GetAllEmployee(out _status);
            List<EmployeeData> employeeList = (from d in employeeDataDMs
                                               group d by d.EmpId into grdEmpAnimals
                                               select new EmployeeData
                                               {
                                                   Name = grdEmpAnimals.Select(x => x.Name).Distinct().FirstOrDefault(),
                                                   Lastname = grdEmpAnimals.Select(x => x.Lastname).Distinct().FirstOrDefault(),
                                                   IsMediaInteractivaEmp = grdEmpAnimals.Select(x => x.IsMediaInteractivaEmp).Distinct().FirstOrDefault(),
                                                   Animals = grdEmpAnimals.Where(x => x.EmpId == grdEmpAnimals.Key).Select(x => new Animal
                                                   {
                                                       Ownername = x.Ownername,
                                                       PetName = x.PetName,
                                                       TypeOfAnimal = x.TypeOfAnimal
                                                   }).ToList()

                                               }).ToList();
            TraceLog.LogActivity(Constants.controllerOut, RouteData, "");
            return Ok(new { data = employeeList, status = _status });
        }


    }
}